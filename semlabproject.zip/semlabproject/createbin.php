<?php
include("connectio.php");
$id=$_POST["id"];
$area=$_POST["area"];
$locality=$_POST["locality"];
$landmark=$_POST["landmark"];
$city=$_POST["city"];
$cycleperiod=$_POST["cycleperiod"];
$sql="INSERT INTO bin values($id,'$area','$locality','$landmark','$city','cycleperiod')";
if ($conn->query($sql) === TRUE) {
    echo '<script>
    window.location.href="admin.html";
    alert("Bin  is created successfully");
    </script>' ;
} 
$conn->close();
?>