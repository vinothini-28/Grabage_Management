<?php
session_start(); // Start the session
include("connectio.php");

$username = $_POST['user'];
$password = $_POST['pass'];

$sql = "SELECT * FROM driverdetails WHERE name='$username' AND password='$password'";
$result = mysqli_query($conn, $sql);
$count = mysqli_num_rows($result);

if ($count == 1) {
    // Store username in session variable
    $_SESSION['username'] = $username;
    // Redirect to driver.php
    header("Location: driver.php");
    exit();
} else {
    // Redirect to main.html if login fails
    header("Location: main.html");
    exit();
}
?>
