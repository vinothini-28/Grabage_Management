<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>main page</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" integrity="sha384-T6LZ72CidjO8n1F7o2CK8t0PhR8uLO4CYGPOmLAsjFU4gVwef8EB0eH1zuz1TNfs" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</head>
<body>
   
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark p-5">
    <div class="container-fluid m-1">
        <p class="fs-3 text-white">Progressing work</p>
    </div>
    <ul class="nav justify-content-end">
        <li class="nav-item">
            <a class="nav-link active text-white" aria-current="page" href="admin.html">Admin dashboard</a>
        </li>
    </ul>
</nav>
<div class="container">
<div class="container p-4">
<div class="row p-3">
 <div class="container p-4">
        <div class="row row-cols-1 row-cols-md-2 g-4"> <!-- Added classes: row-cols-1 row-cols-md-2 g-4 -->
            <?php
            include("connectio.php");
            $sql = "SELECT * FROM driverwork where report='progress'";
            $result = $conn->query($sql);
            if ($result->num_rows) {
                while ($row = $result->fetch_assoc()) {
                    echo '<div class="col">
                        <div class="card text-white bg-success mb-3">
                            <div class="card-header">Complaint</div>
                            <div class="card-body">
                                <h5 class="card-title"></h5>
          <p class="card-text"><b>Driver-id:</b> ' . $row["driverid"] . '</p>
                                <p class="card-text"><b>Bin-id:</b> ' . $row["binid"] . '</p>
                                <p class="card-text"><b>Area:</b> ' . $row["area"] . '</p>
                                
                                <p class="card-text"><b>User Name:</b> ' . $row["name"] . '</p>
                                <p class="card-text"><b>status:</b> ' . $row["report"] . '</p>
                            </div>
                        </div>
                    </div>';
                }
            }
            ?>
        </div>
    </div>
</body>
</html>