<?php
session_start(); // Start the session
include("connectio.php");

// Check if the session variable is set
if(isset($_SESSION['username'])) {
    // Retrieve the driver's name from the session variable
    $driver_name = $_SESSION['username'];

    // Get the ID from the URL parameter
    $id = $_GET["id"];

    // Fetch the driver ID based on the driver name
    $query = "SELECT driverid FROM driverdetails WHERE name='$driver_name'";
    $result = $conn->query($query);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $driverid = $row["driverid"];

        // Fetch the details of the bin
        $sql = "SELECT binid, area, name FROM registercomplaint WHERE binid=$id";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $binid = $row["binid"];
            $area = $row["area"];
            $name = $row["name"];

            // Insert data into the driverwork table
            $insert_query = "INSERT INTO driverwork (driverid, name, binid, area) VALUES ('$driverid', '$name', '$binid', '$area')";
            if ($conn->query($insert_query) === TRUE) {
                echo '<script>
                window.location.href="driver.php";
                alert("Work is assigned");
                </script>';
            } else {
                echo "Error: " . $insert_query . "<br>" . $conn->error;
            }
        } else {
            echo "No bin found with the provided ID.";
        }
    } else {
        echo "No driver found with the provided name.";
    }
} else {
    echo "Driver name not found in session.";
}
?>
