<?php
include("connectio.php");

$username = $_POST['user'];
$password = $_POST['pass'];
$sql = "SELECT * FROM userdetails WHERE name='$username' AND password='$password'";
$result = mysqli_query($conn, $sql);
$count = mysqli_num_rows($result);

if ($count == 1) {
    // Redirect to user.php with username as a parameter
    echo '<script>
    window.location.href= "user.php";
    alert("Login  user. Sign up now.");
    </script>';
   
} else {
    echo '<script>
    window.location.href= "main.html";
    alert("Login failed. Invalid user. Sign up now.");
    </script>';
}
?>
