<?php
session_start(); // Start the session
include("connectio.php");

// Check if the session variable is set
if(isset($_SESSION['username'])) {
    // Retrieve the driver's name from the session variable
    $driver_name = $_SESSION['username'];

    $query = "SELECT driverid FROM driverdetails WHERE name='$driver_name'";
    $result = $conn->query($query);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $driverid = $row["driverid"];
        $id = $_GET["id"];
        $sql = "UPDATE driverwork SET report='completed' WHERE driverid='$driverid' AND binid=$id";
        if($conn->query($sql) === TRUE) {
            echo '<script>
                window.location.href="driver.php";
                alert("Work is completed");
                </script>';
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}
?>
