<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>main page</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" integrity="sha384-T6LZ72CidjO8n1F7o2CK8t0PhR8uLO4CYGPOmLAsjFU4gVwef8EB0eH1zuz1TNfs" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</head>
<body>
   
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark p-5">
           <div class="container-fluid m-1">
              <p class="fs-3 text-white">Register Complaint</p>
            </div>
     
    
      <form class="d-flex" action="register.php">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>
<div class="container p-4">
<div class="row">
<?php
include("connectio.php");
$sql="select * from bin";
$result=$conn->query($sql);
if($result->num_rows)
{
while($row=$result->fetch_assoc()){
$bin=$row["binid"];
echo '<div class="col">
<div class="card" style="width: 18rem;">
  <div class="card-body">
    
    <h6 class="card-subtitle mb-2 text-muted"></h6>
    
<p class="card-text"><b>Bin-id:</b>'.$row["binid"].'</p>
<p class="card-text"><b>area:</b>'.$row["area"].'</p>
<p class="card-text"><b>locality:</b>'.$row["locality"].'</p>
<p class="card-text"><b>landmark:</b>'.$row["landmark"].'</p>
<p class="card-text"><b>city:</b>'.$row["city"].'</p>
<p class="card-text"><b>cycleperiod:</b>'.$row["cycleperiod"].'</p>
    
    <a href="ticket.php?id=' . $bin . '" class="btn btn-warning">Ticket</a>
</div>
</div>
</div>';
}
}
?>
  


</div>
</div>
</body>
</html>
