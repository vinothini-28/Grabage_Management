<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>main page</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" integrity="sha384-T6LZ72CidjO8n1F7o2CK8t0PhR8uLO4CYGPOmLAsjFU4gVwef8EB0eH1zuz1TNfs" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
   
<nav class="navbar navbar-expand-lg navbar-dark bg-dark p-5">
    <div class="container-fluid m-1">
        <p class="fs-3 text-white">User Dashboard</p>
    </div>
</nav>

<div class="container p-5">
    <div class="row">
        <div class="col-sm-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Register complaint</h5>
                    <a href="register1.php" class="btn btn-primary">Register</a>
                </div>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">View complaint</h5>
                    <a href="#" class="btn btn-primary">View</a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container p-5">
    <div class="row">
        <div class="col-sm-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">My profile</h5>
                    <button class="btn btn-primary" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight">My Profile</button>

                    <div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasRight" aria-labelledby="offcanvasRightLabel">
                        <div class="offcanvas-header">
                            <h5 id="offcanvasRightLabel">
                                <?php
                                // Include the database connection file
                                include("connectio.php");

                                // Start the session
                                session_start();

                                // Check if the user is logged in
                                if (isset($_SESSION['user'])) {
                                    // Get the username from the session
                                    $username = $_SESSION['user'];

                                    // Prepare a SQL query to fetch the user details based on the username
                                    $check_sql = "SELECT * FROM userdetails WHERE username = '$username'";

                                    // Execute the query to fetch user details
                                    $check_result = $conn->query($check_sql);

                                    // Check if the query was successful and if the user exists
                                    if ($check_result && $check_result->num_rows > 0) {
                                        // Fetch user details
                                        $row = $check_result->fetch_assoc();
                                        $name = $row['name'];
                                        $email = $row['email'];
                                        $contact = $row['contact'];
                                        $area = $row['area'];
                                        $city = $row['city'];

                                        // Display user details
                                        echo "<b>User Details</b><br><br>";
                                        echo "<table class='table table-hover p-2'>";
                                        echo "<tr><th>Name</th><td>$name</td></tr>";
                                        echo "<tr><th>Email</th><td>$email</td></tr>";
                                        echo "<tr><th>Contact Number</th><td>$contact</td></tr>";
                                        echo "<tr><th>Area</th><td>$area</td></tr>";
                                        echo "<tr><th>City</th><td>$city</td></tr>";
                                        echo "</table>";
                                    } else {
                                        // User does not exist in the database
                                        echo "User does not exist.";
                                    }
                                } else {
                                    // User is not logged in, display login form
                                    if ($_SERVER["REQUEST_METHOD"] == "POST") {
                                        // Form submitted, process login
                                        $input_username = $_POST['user'];
                                        $input_password = $_POST['pass'];

                                        // Query to check if the provided username and password match
                                        $login_query = "SELECT * FROM users WHERE username = '$input_username' AND password = '$input_password'";
                                        $login_result = $conn->query($login_query);

                                        if ($login_result && $login_result->num_rows > 0) {
                                            // Login successful, set session variables
                                            $_SESSION['user'] = $input_username;
                                            header("Location: ".$_SERVER['PHP_SELF']); // Refresh the page to display user details
                                        } else {
                                            // Login failed
                                            echo "Invalid username or password.";
                                        }
                                    }
                                    ?>
                                    <form method="POST">
                                        <label for="username">Username:</label><br>
                                        <input type="text" id="username" name="username"><br>
                                        <label for="password">Password:</label><br>
                                        <input type="password" id="password" name="password"><br><br>
                                        <input type="submit" value="Login">
                                    </form>
                                    <?php
                                }
                                ?>
                            </h5>
                            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                        </div>
                        <div class="offcanvas-body">
                            <!-- Offcanvas body content -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Garbage Separation</h5>
                    <a href="#" class="btn btn-primary">Knowledge</a>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
