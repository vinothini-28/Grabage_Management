<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>main page</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" integrity="sha384-T6LZ72CidjO8n1F7o2CK8t0PhR8uLO4CYGPOmLAsjFU4gVwef8EB0eH1zuz1TNfs" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</head>
<body>
   
     <nav class="navbar navbar-expand-lg navbar-dark bg-dark p-5">
           <div class="container-fluid m-1">
              <p class="fs-3 text-white">Register Complaint</p>
            </div>
     </nav>




<div class="container p-4">



<?php
// Debugging
include("connectio.php");

$id = $_GET["id"];
$sql = "SELECT * FROM bin WHERE binid = $id";
$result = $conn->query($sql);

if ($result->num_rows) {
    $row = $result->fetch_assoc(); // <-- Added semicolon here
    if ($result->num_rows == 1) { // <-- Added semicolon here
        $binid = $row["binid"];
        $area = $row["area"];
        $locality = $row["locality"];
        $landmark = $row["landmark"]; // <-- Fixed syntax
        $city = $row["city"];

        echo '<form action="reg.php" method="POST">
            <div class="mb-3 row">
                <label for="staticEmail" class="col-sm-2 col-form-label"><b>Bin-id:</b></label>
                <div class="col-sm-10">
                    <input type="text" readonly class="form-control-plaintext" id="id" name="id" value="' . $binid . '">
                </div>
            </div>
            <div class="mb-3 row">
                <label for="staticEmail" class="col-sm-2 col-form-label"><b>Area:</b></label>
                <div class="col-sm-10">
                    <input type="text" readonly class="form-control-plaintext" id="area" name="area" value="' . $area . '">
                </div>
            </div>
            <div class="mb-3 row">
                <label for="staticEmail" class="col-sm-2 col-form-label"><b>locality:</b></label>
                <div class="col-sm-10">
                    <input type="text" readonly class="form-control-plaintext" id="locality" name="locality" value="' . $locality . '">
                </div>
            </div>
            <div class="mb-3 row">
                <label for="staticEmail" class="col-sm-2 col-form-label"><b>Landmark:</b></label>
                <div class="col-sm-10">
                    <input type="text" readonly class="form-control-plaintext" id="landmark" name="landmark" value="' . $landmark . '">
                </div>
            </div>
            <div class="mb-3 row">
                <label for="staticEmail" class="col-sm-2 col-form-label"><b>city:</b></label>
                <div class="col-sm-10">
                    <input type="text" readonly class="form-control-plaintext" id="city" name="city" value="' . $city . '">
                </div>
            </div>
<div class="mb-3 row">
                <label for="staticEmail" class="col-sm-2 col-form-label"><b>Name:</b></label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="name" name="name">
                </div>
            </div>
            <div class="mb-3 row">
                <label for="exampleFormControlTextarea1" class="form-label"><b>Complaint:</b></label>
                <textarea class="form-control" id="complaint" name="complaint" rows="3"></textarea>
            </div>
            <button type="submit" class="btn btn-success">Submit</button>
        </form>';
    }
}
?>


  



</div>
</body>
</html>