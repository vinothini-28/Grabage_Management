

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Main Page</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" integrity="sha384-T6LZ72CidjO8n1F7o2CK8t0PhR8uLO4CYGPOmLAsjFU4gVwef8EB0eH1zuz1TNfs" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark p-5">
        <div class="container-fluid m-1">
            <p class="fs-3 text-white">User Dashboard</p>
        </div>
    </nav>

    <div class="container p-5">
        <div class="row">
            <div class="col-sm-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Register Complaint</h5>
                        <a href="register.php" class="btn btn-primary">Register</a>
                    </div>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">View Complaint</h5>
                        <a href="#" class="btn btn-primary">View</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container p-5">
        <div class="row">
            <div class="col-sm-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">My Profile</h5>
                        <button class="btn btn-primary" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasBottom" aria-controls="offcanvasBottom">profile</button>
                        <div class="offcanvas offcanvas-bottom" tabindex="-1" id="offcanvasBottom" aria-labelledby="offcanvasBottomLabel">
                            <div class="offcanvas-header">
                                <h5 id="offcanvasRightLabel"><b>User Details</b><br><br></h5>
                                <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                            </div>
                            <div class="offcanvas-body">
                                <?php
                                      include("connectio.php");

                                  

                                    $sql = "SELECT * FROM userdetails ";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {
                                        echo '<table class="table table-hover p-2">';
                                        while ($row = $result->fetch_assoc()) {
                                            echo '<tbody>
                                                    <tr>
                                                        <th scope="col">Name</th>
                                                        <td>' . $row["name"] . '</td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="col">Email</th>
                                                        <td>' . $row["email"] . '</td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="col">Contact Number</th>
                                                        <td>' . $row["contact"] . '</td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="col">Area</th>
                                                        <td>' . $row["area"] . '</td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="col">City</th>
                                                        <td>' . $row["city"] . '</td>
                                                    </tr>
                                                </tbody>';
                                        }
                                        echo '</table>';
                                    } else {
                                        echo "No user details found.";
                                    }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">garbage separation</h5>
        
        <a href="#" class="btn btn-primary">knowledge</a>
      </div>
    </div>
  </div>
</div>
</div>
          
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>