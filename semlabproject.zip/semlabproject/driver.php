<?php
session_start(); // Start the session
include("connectio.php");
// Check if user is logged in
if (!isset($_SESSION['username'])) {
    // If not logged in, redirect to main.html or login page
    header("Location: main.html");
    exit();
}

// Access username from session variable
$username = $_SESSION['username'];
$sql = "select * from driverdetails where name='$username'";

echo '<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>main page</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" integrity="sha384-T6LZ72CidjO8n1F7o2CK8t0PhR8uLO4CYGPOmLAsjFU4gVwef8EB0eH1zuz1TNfs" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</head>
<body>
   
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark p-5">
    <div class="container-fluid m-1">
        <p class="fs-3 text-white">'.$username.' Dashboard</p>
    </div>
    <ul class="nav justify-content-end">
        <li class="nav-item">
            <a class="nav-link active text-white" aria-current="page" href="logout.php">Home</a>
        </li>
    </ul>
</nav>
       <div class="container p-5">
<div class="row">
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">best route work</h5>
        
        <a href="best.php?id='.$username.';" class="btn btn-primary">Take work</a>
      </div>
    </div>
  </div>
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">complete work </h5>
        
        <a href="workcomplete.php" class="btn btn-primary">view</a>
      </div>
    </div>
  </div>
</div>
</div>
<div class="container p-5">
    <div class="row">
        <div class="col-sm-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">My profile</h5>
                    <button class="btn btn-primary" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasTop" aria-controls="offcanvasTop">My Profile</button>
                </div>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Work Report</h5>
                    <a href="dcomplete.php" class="btn btn-primary">View</a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Offcanvas Markup -->
<div class="offcanvas offcanvas-top" tabindex="-1" id="offcanvasTop" aria-labelledby="offcanvasTopLabel">
  <div class="offcanvas-header">
    <h5 id="offcanvasTopLabel">My Profile</h5>
    <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
    <div class="offcanvas-body">';
$result=$conn->query($sql);
if ($result->num_rows) {
    echo "<b>user details</b><br><br>";
    echo '<table class="table table-hover p-2">
        <thead>
            <tr>
                <th scope="col">Driver-id:</th>
                <th scope="col">Name:</th>
                <th scope="col">Email:</th>
                <th scope="col">Address:</th>
                <th scope="col">Aadhaar:</th>
                <th scope="col">Area:</th>
                <th scope="col">Location:</th>
            </tr>
        </thead>';
    while ($row = $result->fetch_assoc()) {
        echo '<tbody>
            <tr>
                <td>' . $row["driverid"] . '</td>
                <td>' . $row["name"] . '</td>
                <td>' . $row["email"] . '</td>
                <td>' . $row["address"] . '</td>
                <td>' . $row["aadhaar"] . '</td>
                <td>' . $row["area"] . '</td>
                <td>' . $row["location"] . '</td>
            </tr>
        </tbody>';
    }
    echo '</table>';
}
echo '</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>';
?>
