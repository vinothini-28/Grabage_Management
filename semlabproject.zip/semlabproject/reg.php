<?php
include("connectio.php");
$id=$_POST["id"];
$area=$_POST["area"];
$locality=$_POST["locality"];
$landmark=$_POST["landmark"];
$city=$_POST["city"];
$name=$_POST["name"];
$complaint=$_POST["complaint"];
$sql="INSERT INTO registercomplaint ( binid,area,locality,landmark,city,complaint,name)values($id,'$area','$locality','$landmark','$city','$complaint','$name')";
if ($conn->query($sql) === TRUE) {
    echo '<script>
    window.location.href="user.php";
    alert("complaint is registered successfully");
    </script>' ;
} 
$conn->close();
?>