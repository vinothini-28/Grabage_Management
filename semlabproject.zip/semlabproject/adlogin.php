<?php
include("connectio.php");
$username=$_POST['user'];
$password=$_POST['pass'];
$sql= "select * from adminlogin where username='$username' and password='$password'";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_array($result,MYSQLI_ASSOC);
$count=mysqli_num_rows($result);
if($count==1)
{
    
    echo '<script>
    window.location.href="admin.html";
    alert("successfully logged in thanks");
    </script>' ;
}
else
{
    echo '<script>
    window.location.href= "main.html";
alert("login failed invalid user sign up now");
</script> ';
}

?>